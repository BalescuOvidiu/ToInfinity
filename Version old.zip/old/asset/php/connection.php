﻿<?php
define("link","http://toinfinity.atwebpages.com/index.php");
$db=mysqli_connect("localhost","root","","toinfinity");
?>